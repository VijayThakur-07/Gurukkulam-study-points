import { useState, useEffect, useRef } from "react";
import "./styles.css";

// ─── DATA ──────────────────────────────────────────────────────────────────
const courses = [
  { id:1, emoji:"📚", title:"Class 9–10 All Subjects", board:"Bihar Board", price:"₹6,000", period:"/Year", desc:"Complete foundation course covering all subjects for Class 9 & 10 Bihar Board students with weekly tests.", badge:"Foundation", badgeColor:"rgba(99,102,241,0.2)", badgeText:"#818CF8" },
  { id:2, emoji:"🔬", title:"Class 11–12 Science", board:"PCM Stream", price:"₹12,000", period:"/Year", desc:"Advanced Physics, Chemistry & Mathematics for Bihar Board 11th & 12th Science students.", badge:"Most Popular", badgeColor:"rgba(255,107,0,0.2)", badgeText:"#FF6B00" },
  { id:3, emoji:"🎨", title:"Arts & Commerce", board:"All Subjects", price:"₹8,000", period:"/Year", desc:"Comprehensive preparation for Arts & Commerce students. Complete Bihar Board curriculum.", badge:"New Batch", badgeColor:"rgba(16,185,129,0.2)", badgeText:"#34D399" },
];

const videos = [
  { id:1, subject:"Mathematics", topic:"Trigonometry – Basics", teacher:"Rituraj Sir", emoji:"📐", ytId:"rfscVS0vtbw", duration:"45 min" },
  { id:2, subject:"Chemistry", topic:"Chemical Bonding", teacher:"Rituraj Sir", emoji:"⚗️", ytId:"bkNOFGY5Hoo", duration:"38 min" },
  { id:3, subject:"Physics", topic:"Laws of Motion", teacher:"Rituraj Sir", emoji:"⚡", ytId:"ZM8ECpBuQYE", duration:"52 min" },
];

const toppers = [
  { name:"Rahul Kumar", class:"Class 12 Science", score:"98%", emoji:"👑", rank:1 },
  { name:"Priya Singh", class:"Class 12 Science", score:"97%", emoji:"🌟", rank:2 },
  { name:"Aman Verma", class:"Class 10", score:"96%", emoji:"🏆", rank:3 },
  { name:"Kavya Rani", class:"Class 11 Science", score:"95%", emoji:"💫", rank:4 },
  { name:"Rohan Das", class:"Class 11 Science", score:"94%", emoji:"⭐", rank:5 },
];

const facilities = [
  { icon:"🖥️", title:"Smart Classroom", desc:"Modern digital boards & projectors" },
  { icon:"📝", title:"Weekly Test Series", desc:"Regular performance assessment" },
  { icon:"❓", title:"Doubt Clearing", desc:"Daily dedicated doubt sessions" },
  { icon:"👤", title:"Personal Guidance", desc:"Individual student mentoring" },
  { icon:"👨‍🏫", title:"Expert Teachers", desc:"10+ years experience faculty" },
  { icon:"📱", title:"Online Portal", desc:"Study anytime, anywhere" },
];

const testimonials = [
  { name:"Sunita Devi", class:"Parent of Rahul Kumar", text:"My son scored 98% in Class 12. The teachers here are incredibly dedicated. Rituraj Sir's teaching method is outstanding.", emoji:"👩" },
  { name:"Vikash Kumar", class:"Class 12 Student", text:"I was weak in Maths but after joining Gurukulam, I scored 95 in boards. The doubt clearing sessions are very helpful.", emoji:"👦" },
  { name:"Neha Kumari", class:"Class 10 Student", text:"Best coaching in Gopalganj! The study materials and test series helped me achieve First Division.", emoji:"👧" },
];

const sampleTests = [
  { id:1, question:"If sin θ = 3/5, then cos θ = ?", options:["4/5","3/4","5/3","2/5"], correct:0, subject:"Mathematics" },
  { id:2, question:"The valency of Carbon is:", options:["2","3","4","1"], correct:2, subject:"Chemistry" },
  { id:3, question:"Newton's First Law is also called:", options:["Law of Inertia","Law of Action","Law of Force","Law of Energy"], correct:0, subject:"Physics" },
  { id:4, question:"What is the value of √144?", options:["11","12","13","14"], correct:1, subject:"Mathematics" },
  { id:5, question:"Chemical formula of Water is:", options:["H2O2","HO","H2O","H3O"], correct:2, subject:"Chemistry" },
];

const students = [
  { id:"GSP001", name:"Rahul Kumar", class:"12 Science", phone:"9876543210", fee:"Paid", attendance:"92%", score:98 },
  { id:"GSP002", name:"Priya Singh", class:"12 Science", phone:"9876543211", fee:"Paid", attendance:"95%", score:97 },
  { id:"GSP003", name:"Aman Verma", class:"10", phone:"9876543212", fee:"Pending", attendance:"88%", score:96 },
  { id:"GSP004", name:"Kavya Rani", class:"11 Science", phone:"9876543213", fee:"Paid", attendance:"90%", score:95 },
  { id:"GSP005", name:"Rohan Das", class:"11 Science", phone:"9876543214", fee:"Paid", attendance:"85%", score:94 },
];

const inquiries = [
  { name:"Amit Kumar", class:"12 Science", phone:"9876541234", subject:"Physics", date:"2026-03-01", status:"New" },
  { name:"Sita Devi", class:"10", phone:"9876541235", subject:"Maths", date:"2026-03-02", status:"Contacted" },
  { name:"Raj Sharma", class:"11 Science", phone:"9876541236", subject:"Chemistry", date:"2026-03-03", status:"Enrolled" },
];

// ─── NAVBAR ────────────────────────────────────────────────────────────────
function Navbar({ onPortalOpen }) {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const h = () => setScrolled(window.scrollY > 30);
    window.addEventListener("scroll", h);
    return () => window.removeEventListener("scroll", h);
  }, []);
  const scroll = id => document.getElementById(id)?.scrollIntoView({ behavior:"smooth" });
  return (
    <nav className={`navbar ${scrolled ? "scrolled" : ""}`}>
      <div className="nav-logo">
        <span>🎓</span> Gurukulam <span className="accent">Study Point</span>
      </div>
      <ul className="nav-links">
        {[["home","Home"],["courses","Courses"],["faculty","Faculty"],["toppers","Toppers"],["contact","Contact"]].map(([id,label]) => (
          <li key={id}><a onClick={() => scroll(id)}>{label}</a></li>
        ))}
        <li><button className="btn-primary sm" onClick={onPortalOpen}>Student Login</button></li>
      </ul>
    </nav>
  );
}

// ─── HERO ──────────────────────────────────────────────────────────────────
function HeroSection() {
  return (
    <section id="home" className="hero">
      <div className="container hero-grid">
        <div className="hero-content fade-up">
          <div className="hero-badge">
            <span>🏆</span> #1 Coaching in Gopalganj
          </div>
          <h1 className="hero-title">
            <span className="grad-text">Gurukulam</span><br/>Study Point
          </h1>
          <p className="hero-subtitle">Best Coaching for 12th Science</p>
          <p className="hero-location">📍 Brahima More, Gopalganj, Bihar</p>
          <p className="hero-desc">
            Special Bihar Board preparation with expert faculty. Join thousands of successful students who achieved their dreams with Gurukulam Study Point.
          </p>
          <div className="hero-btns">
            <a href="https://wa.me/919507495828?text=Hi!+I+want+to+book+a+Free+Demo+Class+at+Gurukulam+Study+Point" target="_blank" rel="noopener noreferrer">
              <button className="btn-primary">📱 Book Free Demo Class</button>
            </a>
            <button className="btn-outline" onClick={() => document.getElementById("courses")?.scrollIntoView({behavior:"smooth"})}>
              View Courses →
            </button>
          </div>
          <div className="hero-stats">
            {[["500+","Students"],["98%","Top Score"],["10+","Yrs Experience"]].map(([n,l]) => (
              <div key={l} className="hero-stat">
                <div className="hero-stat-num">{n}</div>
                <div className="hero-stat-label">{l}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="hero-visual">
          <div className="hero-circle float-anim">
            <div className="hero-icon-big">🎓</div>
          </div>
          <div className="hero-tag tag-orange">🔥 New Batch Starting!</div>
          <div className="hero-tag tag-green">✅ 80% First Division</div>
        </div>
      </div>
    </section>
  );
}

// ─── COURSES ───────────────────────────────────────────────────────────────
function CoursesSection() {
  return (
    <section id="courses" className="section section-dark">
      <div className="container">
        <div className="section-header">
          <div className="section-label">Our Programs</div>
          <h2 className="section-title">Choose Your <span className="grad-text">Course</span></h2>
          <p className="section-sub">Expert-designed curriculum aligned with Bihar Board syllabus</p>
        </div>
        <div className="course-grid">
          {courses.map(c => (
            <div key={c.id} className="glass course-card">
              <div className="course-img">{c.emoji}</div>
              <div className="course-body">
                <span className="course-badge" style={{background:c.badgeColor,color:c.badgeText}}>{c.badge}</span>
                <h3 className="course-title">{c.title}</h3>
                <p className="course-board">{c.board}</p>
                <p className="course-desc">{c.desc}</p>
                <div className="course-footer">
                  <div>
                    <span className="course-price">{c.price}</span>
                    <span className="course-period">{c.period}</span>
                  </div>
                  <a href={`https://wa.me/919507495828?text=I+want+to+enroll+in+${encodeURIComponent(c.title)}`} target="_blank" rel="noopener noreferrer">
                    <button className="btn-primary sm">Enroll Now</button>
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── FACULTY ───────────────────────────────────────────────────────────────
function FacultySection() {
  return (
    <section id="faculty" className="section">
      <div className="container">
        <div className="section-header">
          <div className="section-label">Meet Our Faculty</div>
          <h2 className="section-title">Expert <span className="grad-text">Educators</span></h2>
        </div>
        <div className="faculty-center">
          <div className="glass-warm faculty-card">
            <div className="faculty-avatar">👨‍🏫</div>
            <h3 className="faculty-name">Rituraj Sir</h3>
            <p className="faculty-subject">Mathematics Expert</p>
            <p className="faculty-bio">
              With over 10 years of dedicated teaching experience, Rituraj Sir has helped hundreds of students achieve top scores in Bihar Board examinations. Known for making complex concepts simple and understandable.
            </p>
            <div className="faculty-stats">
              {[["10+","Years Experience"],["500+","Students Taught"],["98%","Top Score"]].map(([n,l]) => (
                <div key={l} className="faculty-stat">
                  <div className="faculty-stat-num">{n}</div>
                  <div className="faculty-stat-label">{l}</div>
                </div>
              ))}
            </div>
            <div className="faculty-tags">
              {["Mathematics","Algebra","Trigonometry","Calculus","Statistics"].map(s => (
                <span key={s} className="faculty-tag">{s}</span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── VIDEOS ────────────────────────────────────────────────────────────────
function VideoSection({ onVideoOpen }) {
  return (
    <section className="section section-mid">
      <div className="container">
        <div className="section-header">
          <div className="section-label">Free Lectures</div>
          <h2 className="section-title">Sample <span className="grad-text">Video Lectures</span></h2>
          <p className="section-sub">Watch free sample lectures from our expert faculty</p>
        </div>
        <div className="video-grid">
          {videos.map(v => (
            <div key={v.id} className="glass video-card" onClick={() => onVideoOpen(v)}>
              <div className="video-thumb">
                <span className="video-emoji">{v.emoji}</span>
                <div className="play-btn">▶</div>
                <div className="video-duration">{v.duration}</div>
              </div>
              <div className="video-body">
                <span className="video-subject">{v.subject}</span>
                <h4 className="video-title">{v.topic}</h4>
                <p className="video-teacher">👨‍🏫 {v.teacher}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── TOPPERS ───────────────────────────────────────────────────────────────
function TopperSection() {
  const colors = ["linear-gradient(135deg,#D97706,#92400E)","linear-gradient(135deg,#4F46E5,#312E81)","linear-gradient(135deg,#047857,#065F46)","linear-gradient(135deg,#7C3AED,#4C1D95)","linear-gradient(135deg,#DC2626,#991B1B)"];
  return (
    <section id="toppers" className="section section-dark2">
      <div className="container">
        <div className="section-header">
          <div className="section-label">Our Pride</div>
          <h2 className="section-title">🏆 Topper <span className="grad-text">Students</span></h2>
        </div>
        <div className="toppers-grid">
          {toppers.map((t,i) => (
            <div key={i} className="glass topper-card">
              <div className="topper-avatar" style={{background:colors[i%colors.length]}}>{t.emoji}</div>
              <div className="topper-score grad-text">{t.score}</div>
              <h4 className="topper-name">{t.name}</h4>
              <p className="topper-class">{t.class}</p>
              <div className="topper-rank">Rank #{i+1}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── STATS ─────────────────────────────────────────────────────────────────
function StatsSection() {
  const [counted, setCounted] = useState(false);
  const ref = useRef();
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => { if(e.isIntersecting) setCounted(true); }, {threshold:0.3});
    if(ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  return (
    <section ref={ref} className="section section-accent">
      <div className="container">
        <div className="section-header">
          <div className="section-label">Our Achievements</div>
          <h2 className="section-title">Results that <span className="grad-text">Speak</span></h2>
        </div>
        <div className="stats-grid">
          {[["500+","Students Passed","🎓"],["80%","Achieve First Division","🏆"],["98%","Top Board Score","⭐"],["10+","Years of Excellence","🌟"]].map(([n,l,e]) => (
            <div key={l} className={`glass-warm stat-card ${counted?"counted":""}`}>
              <div className="stat-emoji">{e}</div>
              <div className="stat-number">{n}</div>
              <div className="stat-label">{l}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── FACILITIES ────────────────────────────────────────────────────────────
function FacilitiesSection() {
  return (
    <section className="section">
      <div className="container">
        <div className="section-header">
          <div className="section-label">What We Offer</div>
          <h2 className="section-title">World-Class <span className="grad-text">Facilities</span></h2>
        </div>
        <div className="facilities-grid">
          {facilities.map((f,i) => (
            <div key={i} className="glass facility-card">
              <div className="facility-icon">{f.icon}</div>
              <h4 className="facility-title">{f.title}</h4>
              <p className="facility-desc">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── TESTIMONIALS ──────────────────────────────────────────────────────────
function TestimonialsSection() {
  return (
    <section className="section section-mid">
      <div className="container">
        <div className="section-header">
          <div className="section-label">Student Voice</div>
          <h2 className="section-title">What Our Students <span className="grad-text">Say</span></h2>
        </div>
        <div className="testimonials-grid">
          {testimonials.map((t,i) => (
            <div key={i} className="glass-warm testimonial-card">
              <div className="testimonial-author">
                <div className="testimonial-avatar">{t.emoji}</div>
                <div>
                  <div className="testimonial-name">{t.name}</div>
                  <div className="testimonial-class">{t.class}</div>
                </div>
              </div>
              <p className="testimonial-text">{t.text}</p>
              <div className="stars">⭐⭐⭐⭐⭐</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── GALLERY ───────────────────────────────────────────────────────────────
function GallerySection() {
  const items = [
    {emoji:"🏫",bg:"linear-gradient(135deg,#1e3a5f,#0f2240)"},
    {emoji:"📚",bg:"linear-gradient(135deg,#3d1a00,#5c2800)"},
    {emoji:"🖥️",bg:"linear-gradient(135deg,#0a2e1a,#0d4a2a)"},
    {emoji:"✏️",bg:"linear-gradient(135deg,#2d0050,#4a0080)"},
    {emoji:"🔬",bg:"linear-gradient(135deg,#001a3d,#002d6b)"},
    {emoji:"🎯",bg:"linear-gradient(135deg,#3d1200,#6b2000)"},
  ];
  return (
    <section className="section">
      <div className="container">
        <div className="section-header">
          <div className="section-label">Our Campus</div>
          <h2 className="section-title">Campus <span className="grad-text">Gallery</span></h2>
        </div>
        <div className="gallery-grid">
          {items.map((item,i) => (
            <div key={i} className={`gallery-item ${i===0?"gallery-wide":""}`} style={{background:item.bg}}>
              <span>{item.emoji}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ─── CONTACT ───────────────────────────────────────────────────────────────
function AdmissionForm() {
  const [form, setForm] = useState({ name:"", class:"", phone:"", subject:"" });
  const [submitted, setSubmitted] = useState(false);
  const handle = e => setForm(p => ({...p,[e.target.name]:e.target.value}));
  const submit = () => {
    if(!form.name||!form.phone) return alert("Please fill Name and Phone");
    setSubmitted(true);
    const msg = `Hello Gurukulam Study Point! 🙏\nNew Admission Inquiry:\nName: ${form.name}\nClass: ${form.class}\nSubject: ${form.subject}\nPhone: ${form.phone}`;
    window.open(`https://wa.me/919507495828?text=${encodeURIComponent(msg)}`, "_blank");
  };
  if(submitted) return (
    <div className="form-success">
      <div style={{fontSize:"64px"}}>✅</div>
      <h3>Inquiry Submitted!</h3>
      <p>We'll contact you shortly. WhatsApp chat opened.</p>
    </div>
  );
  return (
    <div>
      <div className="form-group">
        <label className="form-label">Full Name *</label>
        <input className="form-input" name="name" placeholder="Enter your full name" value={form.name} onChange={handle} />
      </div>
      <div className="form-row">
        <div className="form-group">
          <label className="form-label">Class</label>
          <select className="form-input" name="class" value={form.class} onChange={handle}>
            <option value="">Select Class</option>
            {["9","10","11 Science","11 Arts","12 Science","12 Arts","12 Commerce"].map(c => <option key={c} value={c}>Class {c}</option>)}
          </select>
        </div>
        <div className="form-group">
          <label className="form-label">Subject Interest</label>
          <select className="form-input" name="subject" value={form.subject} onChange={handle}>
            <option value="">Select Subject</option>
            {["Mathematics","Physics","Chemistry","Biology","All Subjects"].map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>
      <div className="form-group">
        <label className="form-label">Phone Number *</label>
        <input className="form-input" name="phone" placeholder="+91 XXXXX XXXXX" value={form.phone} onChange={handle} />
      </div>
      <button className="btn-primary full" onClick={submit}>📱 Submit & Open WhatsApp</button>
    </div>
  );
}

function ContactSection() {
  return (
    <section id="contact" className="section section-mid">
      <div className="container">
        <div className="section-header">
          <div className="section-label">Get In Touch</div>
          <h2 className="section-title">Admission <span className="grad-text">Inquiry</span></h2>
        </div>
        <div className="contact-grid">
          <div>
            <h3 className="contact-info-title">Contact Information</h3>
            {[
              {icon:"📍",label:"Address",val:"Brahima More, Gopalganj, Bihar"},
              {icon:"📱",label:"WhatsApp/Call",val:"+91 9507495828"},
              {icon:"⏰",label:"Timing",val:"7 AM – 8 PM (Mon–Sat)"},
              {icon:"📧",label:"Email",val:"gurukulamstudypoint@gmail.com"},
            ].map(c => (
              <div key={c.label} className="contact-item">
                <div className="contact-icon">{c.icon}</div>
                <div>
                  <div className="contact-label">{c.label}</div>
                  <div className="contact-val">{c.val}</div>
                </div>
              </div>
            ))}
            <div className="map-placeholder">
              🗺️ <span>Brahima More, Gopalganj, Bihar</span>
            </div>
          </div>
          <div className="glass contact-form">
            <h3 className="form-title">Book Free Demo Class</h3>
            <AdmissionForm />
          </div>
        </div>
      </div>
    </section>
  );
}

// ─── FOOTER ────────────────────────────────────────────────────────────────
function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <div className="footer-logo">🎓 Gurukulam <span>Study Point</span></div>
          <p className="footer-desc">Best Coaching for 12th Science – Special Bihar Boards. Building tomorrow's leaders today.</p>
          <div className="footer-socials">
            <a href="https://wa.me/919507495828" target="_blank" rel="noopener noreferrer" className="social-btn wa">💬</a>
            <div className="social-btn">📘</div>
            <div className="social-btn">📺</div>
          </div>
        </div>
        <div>
          <h4 className="footer-heading">Quick Links</h4>
          {["Courses","Faculty","Toppers","Gallery","Contact"].map(l => (
            <div key={l} className="footer-link">→ {l}</div>
          ))}
        </div>
        <div>
          <h4 className="footer-heading">Courses</h4>
          {["Class 9-10 (Bihar Board)","Class 11-12 Science","Arts & Commerce","Test Series","Online Portal"].map(l => (
            <div key={l} className="footer-link">→ {l}</div>
          ))}
        </div>
      </div>
      <div className="footer-bottom">
        © 2026 Gurukulam Study Point, Gopalganj, Bihar. All Rights Reserved. | Best Coaching in Gopalganj | Bihar Board Coaching
      </div>
    </footer>
  );
}

// ─── VIDEO MODAL ────────────────────────────────────────────────────────────
function VideoModal({ video, onClose }) {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <div>
            <h4>{video.topic}</h4>
            <p>{video.subject} • {video.teacher}</p>
          </div>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>
        <div className="modal-video">
          <iframe width="100%" height="100%" src={`https://www.youtube.com/embed/${video.ytId}`} frameBorder="0" allowFullScreen />
        </div>
      </div>
    </div>
  );
}

// ─── STUDENT PORTAL ────────────────────────────────────────────────────────
function StudentPortal({ onClose }) {
  const [loggedIn, setLoggedIn] = useState(false);
  const [page, setPage] = useState("dashboard");
  if(!loggedIn) return (
    <div className="modal-overlay">
      <div className="login-box glass">
        <button className="modal-close" onClick={onClose}>✕</button>
        <div className="login-header">
          <div style={{fontSize:"48px"}}>🎓</div>
          <h2>Student Login</h2>
          <p>Access your learning portal</p>
        </div>
        <div className="form-group">
          <label className="form-label">Student ID</label>
          <input className="form-input" placeholder="e.g. GSP001" />
        </div>
        <div className="form-group">
          <label className="form-label">Password</label>
          <input className="form-input" type="password" placeholder="Enter password" />
        </div>
        <button className="btn-primary full" onClick={() => setLoggedIn(true)}>Login to Portal →</button>
        <p className="demo-note">Demo: Any ID & password works</p>
        <div className="wa-note">New admission? <a href="https://wa.me/919507495828" target="_blank" rel="noopener noreferrer">Contact us on WhatsApp →</a></div>
      </div>
    </div>
  );
  const navItems = [
    {id:"dashboard",icon:"🏠",label:"Dashboard"},
    {id:"courses",icon:"📚",label:"My Courses"},
    {id:"videos",icon:"🎬",label:"Video Lectures"},
    {id:"materials",icon:"📄",label:"Study Materials"},
    {id:"tests",icon:"✏️",label:"Online Tests"},
    {id:"results",icon:"📊",label:"My Results"},
    {id:"attendance",icon:"📅",label:"Attendance"},
    {id:"fees",icon:"💳",label:"Fee Status"},
    {id:"announcements",icon:"📢",label:"Announcements"},
  ];
  return (
    <div className="portal-overlay">
      <div className="portal-sidebar">
        <div className="portal-brand">
          <div className="portal-brand-name">🎓 Gurukulam</div>
          <div className="portal-brand-sub">Student Portal</div>
        </div>
        {navItems.map(n => (
          <div key={n.id} className={`sidebar-link ${page===n.id?"active":""}`} onClick={() => setPage(n.id)}>
            <span>{n.icon}</span>{n.label}
          </div>
        ))}
        <div className="sidebar-exit">
          <button className="btn-outline full sm" onClick={onClose}>✕ Exit Portal</button>
        </div>
      </div>
      <div className="portal-main">
        <div className="portal-topbar">
          <div>
            <div className="portal-greeting">Welcome back,</div>
            <h2 className="portal-username">Rahul Kumar 👋</h2>
          </div>
          <div className="portal-avatar">R</div>
        </div>
        {page==="dashboard" && <StudentDashboard />}
        {page==="courses" && <StudentCourses />}
        {page==="videos" && <StudentVideos />}
        {page==="materials" && <StudentMaterials />}
        {page==="tests" && <OnlineTest />}
        {page==="results" && <StudentResults />}
        {page==="attendance" && <StudentAttendance />}
        {page==="fees" && <FeeStatus />}
        {page==="announcements" && <Announcements />}
      </div>
    </div>
  );
}

function StudentDashboard() {
  return (
    <div>
      <div className="kpi-grid">
        {[{label:"Attendance",value:"92%",icon:"📅",color:"var(--green)"},{label:"Test Score",value:"98%",icon:"📊",color:"var(--saffron)"},{label:"Fee Status",value:"Paid",icon:"💳",color:"var(--green)"},{label:"Rank",value:"#1",icon:"🏆",color:"var(--gold)"}].map(s => (
          <div key={s.label} className="glass kpi-card">
            <div className="kpi-icon">{s.icon}</div>
            <div className="kpi-value" style={{color:s.color}}>{s.value}</div>
            <div className="kpi-label">{s.label}</div>
          </div>
        ))}
      </div>
      <div className="dashboard-grid">
        <div className="glass dash-card">
          <h4 className="dash-card-title">📅 Recent Tests</h4>
          {[["Mathematics","85%","Mar 1"],["Chemistry","78%","Feb 24"],["Physics","91%","Feb 18"]].map(([s,sc,d]) => (
            <div key={s} className="dash-row">
              <span>{s}</span>
              <div className="dash-row-right"><span className="score">{sc}</span><span className="date">{d}</span></div>
            </div>
          ))}
        </div>
        <div className="glass dash-card">
          <h4 className="dash-card-title">📢 Announcements</h4>
          {[["Unit Test – Math","Tomorrow 10 AM","🔴"],["Holiday on Holi","March 14","🟡"],["New Study Material","Available Now","🟢"]].map(([t,d,c]) => (
            <div key={t} className="dash-row">
              <span>{c}</span>
              <div><div className="ann-title">{t}</div><div className="ann-date">{d}</div></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function StudentCourses() {
  return (
    <div>
      <h3 className="page-title">My Enrolled Courses</h3>
      <div className="courses-portal-grid">
        {[{title:"Class 12 Science – PCM",progress:72,icon:"🔬",chapters:24,done:17},{title:"Mathematics Advanced",progress:85,icon:"📐",chapters:18,done:15},{title:"Chemistry Full Course",progress:60,icon:"⚗️",chapters:20,done:12}].map(c => (
          <div key={c.title} className="glass portal-course-card">
            <div className="portal-course-icon">{c.icon}</div>
            <h4 className="portal-course-title">{c.title}</h4>
            <p className="portal-course-sub">{c.done}/{c.chapters} Chapters</p>
            <div className="progress-bar"><div className="progress-fill" style={{width:`${c.progress}%`}} /></div>
            <div className="progress-meta"><span>Progress</span><span style={{color:"var(--saffron)"}}>{c.progress}%</span></div>
            <button className="btn-primary full" style={{marginTop:"12px",fontSize:"13px"}}>Continue Learning →</button>
          </div>
        ))}
      </div>
    </div>
  );
}

function StudentVideos() {
  const [playing, setPlaying] = useState(null);
  return (
    <div>
      <h3 className="page-title">Video Lectures</h3>
      {playing ? (
        <div>
          <button className="btn-outline" style={{marginBottom:"16px"}} onClick={() => setPlaying(null)}>← Back to List</button>
          <div className="video-player-wrap">
            <iframe width="100%" height="100%" src={`https://www.youtube.com/embed/${playing.ytId}`} frameBorder="0" allowFullScreen />
          </div>
          <h4 style={{marginTop:"16px",fontWeight:"700"}}>{playing.topic}</h4>
          <p style={{color:"var(--text-muted)",marginTop:"4px"}}>{playing.subject} • {playing.teacher}</p>
        </div>
      ) : (
        <div className="video-grid">
          {videos.map(v => (
            <div key={v.id} className="glass video-card" onClick={() => setPlaying(v)}>
              <div className="video-thumb">
                <span className="video-emoji">{v.emoji}</span>
                <div className="play-btn">▶</div>
              </div>
              <div className="video-body">
                <span className="video-subject">{v.subject}</span>
                <h4 className="video-title">{v.topic}</h4>
                <p className="video-teacher">{v.duration}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function StudentMaterials() {
  return (
    <div>
      <h3 className="page-title">Study Materials</h3>
      <div className="materials-list">
        {[
          {title:"Mathematics – Chapter 1 to 5 Notes",subject:"Mathematics",size:"2.4 MB"},
          {title:"Chemistry Formulas & Reactions Sheet",subject:"Chemistry",size:"1.8 MB"},
          {title:"Physics Derivations Master Notes",subject:"Physics",size:"3.1 MB"},
          {title:"Previous Year Question Papers 2024",subject:"All Subjects",size:"5.6 MB"},
          {title:"Bihar Board Exam Pattern Guide",subject:"General",size:"0.9 MB"},
        ].map(m => (
          <div key={m.title} className="glass material-row">
            <span className="material-icon">📄</span>
            <div className="material-info">
              <h4>{m.title}</h4>
              <p>{m.subject} • {m.size} • PDF</p>
            </div>
            <button className="btn-primary sm">⬇ Download</button>
          </div>
        ))}
      </div>
    </div>
  );
}

function OnlineTest() {
  const [started, setStarted] = useState(false);
  const [current, setCurrent] = useState(0);
  const [selected, setSelected] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [time, setTime] = useState(300);
  useEffect(() => {
    if(!started||submitted) return;
    const t = setInterval(() => setTime(p => { if(p<=1){clearInterval(t);setSubmitted(true);return 0;} return p-1; }), 1000);
    return () => clearInterval(t);
  }, [started,submitted]);
  const score = Object.entries(selected).filter(([i,a]) => sampleTests[+i].correct===a).length;
  if(!started) return (
    <div className="test-start">
      <div style={{fontSize:"72px"}}>📝</div>
      <h3>Online Test</h3>
      <p>Mixed Subjects Test • 5 Questions • 5 Minutes</p>
      <div className="test-info-grid">
        {[["📚","5 Questions"],["⏱️","5 Minutes"],["📊","Auto Score"],["🏆","Leaderboard"]].map(([e,l]) => (
          <div key={l} className="glass test-info-card"><span>{e}</span><span>{l}</span></div>
        ))}
      </div>
      <button className="btn-primary" style={{padding:"14px 32px",fontSize:"16px"}} onClick={() => setStarted(true)}>Start Test →</button>
    </div>
  );
  if(submitted) {
    const pct = Math.round((score/sampleTests.length)*100);
    return (
      <div className="test-start">
        <div style={{fontSize:"72px"}}>{pct>=80?"🏆":pct>=60?"👍":"📚"}</div>
        <h3>Test Completed!</h3>
        <div className="test-pct grad-text">{pct}%</div>
        <p style={{color:"var(--text-muted)"}}>{score} out of {sampleTests.length} correct</p>
        <div className="test-review-grid">
          {sampleTests.map((q,i) => (
            <div key={i} className="glass test-review-card" style={{borderLeft:`3px solid ${selected[i]===q.correct?"var(--green)":"var(--red)"}`}}>
              <div style={{fontSize:"20px"}}>{selected[i]===q.correct?"✅":"❌"}</div>
              <div style={{fontSize:"12px",color:"var(--text-muted)"}}>Q{i+1} – {q.subject}</div>
            </div>
          ))}
        </div>
        <button className="btn-primary" style={{marginTop:"24px"}} onClick={() => {setStarted(false);setCurrent(0);setSelected({});setSubmitted(false);setTime(300);}}>Retake Test</button>
      </div>
    );
  }
  const q = sampleTests[current];
  const mins = Math.floor(time/60).toString().padStart(2,"0");
  const secs = (time%60).toString().padStart(2,"0");
  return (
    <div className="test-active">
      <div className="test-header">
        <span className="badge badge-orange">{q.subject}</span>
        <span style={{color:"var(--text-muted)",fontSize:"13px"}}>Q {current+1}/{sampleTests.length}</span>
        <span className="test-timer" style={{color:time<60?"var(--red)":"var(--saffron)"}}>⏱ {mins}:{secs}</span>
      </div>
      <div className="progress-bar"><div className="progress-fill" style={{width:`${(current/sampleTests.length)*100}%`}} /></div>
      <div className="glass test-question">{q.question}</div>
      <div className="test-options">
        {q.options.map((opt,i) => (
          <div key={i} className={`test-option ${selected[current]===i?"selected":""}`} onClick={() => setSelected(p => ({...p,[current]:i}))}>
            <div className="option-letter">{String.fromCharCode(65+i)}</div>
            <span>{opt}</span>
          </div>
        ))}
      </div>
      <div className="test-nav">
        <button className="btn-outline" onClick={() => setCurrent(p => Math.max(0,p-1))} disabled={current===0}>← Prev</button>
        {current<sampleTests.length-1
          ? <button className="btn-primary" onClick={() => setCurrent(p=>p+1)}>Next →</button>
          : <button className="btn-primary" onClick={() => setSubmitted(true)}>Submit ✓</button>
        }
      </div>
    </div>
  );
}

function StudentResults() {
  return (
    <div>
      <h3 className="page-title">My Results</h3>
      <div className="table-wrap">
        <table className="data-table">
          <thead><tr><th>Test</th><th>Subject</th><th>Date</th><th>Score</th><th>Grade</th><th>Status</th></tr></thead>
          <tbody>
            {[["Unit Test 1","Mathematics","Mar 1, 2026","85/100","A","Pass"],["Unit Test 1","Chemistry","Feb 24, 2026","78/100","B+","Pass"],["Unit Test 1","Physics","Feb 18, 2026","91/100","A+","Pass"],["Monthly Test","All Subjects","Feb 10, 2026","255/300","A","Pass"]].map(([t,s,d,sc,g,st]) => (
              <tr key={t+d}>
                <td>{t}</td><td>{s}</td><td style={{color:"var(--text-muted)"}}>{d}</td>
                <td style={{fontWeight:"600",color:"var(--saffron)"}}>{sc}</td>
                <td><span className="badge badge-orange">{g}</span></td>
                <td><span className="badge badge-green">{st}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function StudentAttendance() {
  return (
    <div>
      <h3 className="page-title">Attendance Record</h3>
      <div className="kpi-grid">
        <div className="glass kpi-card"><div className="kpi-icon">📅</div><div className="kpi-value" style={{color:"var(--green)"}}>92%</div><div className="kpi-label">Overall</div></div>
        <div className="glass kpi-card"><div className="kpi-icon">✅</div><div className="kpi-value" style={{color:"var(--saffron)"}}>55</div><div className="kpi-label">Attended</div></div>
        <div className="glass kpi-card"><div className="kpi-icon">❌</div><div className="kpi-value" style={{color:"var(--red)"}}>5</div><div className="kpi-label">Missed</div></div>
      </div>
      <div className="glass dash-card" style={{marginTop:"24px"}}>
        <h4 className="dash-card-title">Monthly Trend</h4>
        <div className="bar-chart">
          {[["Jan",88],["Feb",92],["Mar",95]].map(([m,v]) => (
            <div key={m} className="bar-col">
              <div className="bar-wrap"><div className="bar-fill" style={{height:`${v}%`}} /></div>
              <div className="bar-label">{m}</div>
              <div className="bar-val">{v}%</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function FeeStatus() {
  const [receipt, setReceipt] = useState(false);
  return (
    <div>
      <h3 className="page-title">Fee Details</h3>
      <div className="glass-warm fee-card">
        <div className="fee-header">
          <h4>Class 12 Science – Annual Fee</h4>
          <span className="badge badge-green">Paid</span>
        </div>
        {[["Course","Class 11-12 Science PCM"],["Amount","₹12,000"],["Paid","₹12,000"],["Due","₹0"],["Next Due","April 2027"],["Receipt","GSP-2026-001"]].map(([l,v]) => (
          <div key={l} className="fee-row">
            <span>{l}</span><span style={{fontWeight:"600"}}>{v}</span>
          </div>
        ))}
        <button className="btn-outline full" style={{marginTop:"20px"}} onClick={() => setReceipt(true)}>📄 Download Receipt</button>
        {receipt && <div className="receipt-success">✅ Receipt downloaded: GSP-2026-001.pdf</div>}
      </div>
    </div>
  );
}

function Announcements() {
  return (
    <div>
      <h3 className="page-title">Announcements</h3>
      <div className="announcements-list">
        {[
          {title:"Unit Test – Mathematics",body:"Unit Test for Chapter 6 & 7 on March 8, 2026 at 10:00 AM. Syllabus: Trigonometry & Algebra.",date:"Mar 6, 2026",icon:"📝"},
          {title:"Holiday – Holi Festival",body:"Coaching will remain closed on March 14, 2026 for Holi. Regular classes resume March 15.",date:"Mar 5, 2026",icon:"🎉"},
          {title:"New Study Material Available",body:"Chemistry Chapter 12 notes and practice questions have been uploaded. Download from materials section.",date:"Mar 3, 2026",icon:"📚"},
          {title:"Fee Reminder",body:"Annual fee for 2026-27 will be due in April 2026. Early payment discount available.",date:"Mar 1, 2026",icon:"💳"},
        ].map(a => (
          <div key={a.title} className="glass ann-card">
            <span className="ann-icon">{a.icon}</span>
            <div className="ann-content">
              <div className="ann-row">
                <h4>{a.title}</h4>
                <span className="ann-date-small">{a.date}</span>
              </div>
              <p>{a.body}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── ADMIN DASHBOARD ───────────────────────────────────────────────────────
function AdminDashboard({ onClose }) {
  const [loggedIn, setLoggedIn] = useState(false);
  const [page, setPage] = useState("overview");
  if(!loggedIn) return (
    <div className="modal-overlay">
      <div className="login-box glass">
        <button className="modal-close" onClick={onClose}>✕</button>
        <div className="login-header">
          <div style={{fontSize:"48px"}}>🔐</div>
          <h2>Admin Login</h2>
        </div>
        <div className="form-group">
          <label className="form-label">Password</label>
          <input className="form-input" type="password" placeholder="Admin password" />
        </div>
        <button className="btn-primary full" onClick={() => setLoggedIn(true)}>Access Admin Panel</button>
        <p className="demo-note">Demo: Any password works</p>
      </div>
    </div>
  );
  const adminNav = [
    {id:"overview",icon:"📊",label:"Overview"},
    {id:"students",icon:"👥",label:"Students"},
    {id:"inquiries",icon:"📩",label:"Inquiries"},
    {id:"analytics",icon:"📈",label:"Analytics"},
    {id:"fees",icon:"💰",label:"Fee Tracking"},
    {id:"content",icon:"📋",label:"Content Mgmt"},
  ];
  return (
    <div className="portal-overlay">
      <div className="portal-sidebar">
        <div className="portal-brand">
          <div className="portal-brand-name">⚙️ Admin Panel</div>
          <div className="portal-brand-sub">Gurukulam Study Point</div>
        </div>
        {adminNav.map(n => (
          <div key={n.id} className={`sidebar-link ${page===n.id?"active":""}`} onClick={() => setPage(n.id)}>
            <span>{n.icon}</span>{n.label}
          </div>
        ))}
        <div className="sidebar-exit">
          <button className="btn-outline full sm" onClick={onClose}>✕ Exit</button>
        </div>
      </div>
      <div className="portal-main">
        <div className="portal-topbar">
          <h2 className="portal-username">{adminNav.find(n=>n.id===page)?.icon} {adminNav.find(n=>n.id===page)?.label}</h2>
          <span style={{fontSize:"13px",color:"var(--text-muted)"}}>Logged in as Admin</span>
        </div>
        {page==="overview" && <AdminOverview />}
        {page==="students" && <AdminStudents />}
        {page==="inquiries" && <AdminInquiries />}
        {page==="analytics" && <AdminAnalytics />}
        {page==="fees" && <AdminFees />}
        {page==="content" && <AdminContent />}
      </div>
    </div>
  );
}

function AdminOverview() {
  return (
    <div>
      <div className="kpi-grid">
        {[{label:"Total Students",value:"500+",icon:"👥",change:"+12%"},{label:"Active Courses",value:"3",icon:"📚",change:"Stable"},{label:"New Inquiries",value:"3",icon:"📩",change:"+33%"},{label:"Revenue",value:"₹2.4L",icon:"💰",change:"+18%"}].map(s => (
          <div key={s.label} className="glass kpi-card">
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:"10px"}}>
              <span style={{fontSize:"24px"}}>{s.icon}</span>
              <span className="badge badge-green">{s.change}</span>
            </div>
            <div className="kpi-value" style={{color:"var(--saffron)"}}>{s.value}</div>
            <div className="kpi-label">{s.label}</div>
          </div>
        ))}
      </div>
      <div className="dashboard-grid">
        <div className="glass dash-card">
          <h4 className="dash-card-title">Recent Inquiries</h4>
          {inquiries.map(i => (
            <div key={i.name} className="dash-row">
              <div><div style={{fontWeight:"500"}}>{i.name}</div><div style={{fontSize:"12px",color:"var(--text-muted)"}}>{i.class} • {i.subject}</div></div>
              <span className={`badge ${i.status==="Enrolled"?"badge-green":"badge-orange"}`}>{i.status}</span>
            </div>
          ))}
        </div>
        <div className="glass dash-card">
          <h4 className="dash-card-title">Fee Collection</h4>
          {[["Class 12 Science","₹1,44,000",80],["Class 9-10","₹72,000",75],["Arts & Commerce","₹24,000",60]].map(([c,a,p]) => (
            <div key={c} style={{marginBottom:"14px"}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:"5px"}}>
                <span style={{fontSize:"13px"}}>{c}</span><span style={{fontSize:"13px",fontWeight:"600",color:"var(--saffron)"}}>{a}</span>
              </div>
              <div className="progress-bar"><div className="progress-fill" style={{width:`${p}%`}} /></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AdminStudents() {
  const [search, setSearch] = useState("");
  const filtered = students.filter(s => s.name.toLowerCase().includes(search.toLowerCase()) || s.id.includes(search));
  return (
    <div>
      <div className="table-actions">
        <input className="form-input" style={{maxWidth:"280px"}} placeholder="🔍 Search students..." value={search} onChange={e => setSearch(e.target.value)} />
        <button className="btn-primary sm">+ Add Student</button>
      </div>
      <div className="table-wrap">
        <table className="data-table">
          <thead><tr><th>ID</th><th>Name</th><th>Class</th><th>Phone</th><th>Attendance</th><th>Score</th><th>Fee</th><th>Action</th></tr></thead>
          <tbody>
            {filtered.map(s => (
              <tr key={s.id}>
                <td style={{fontWeight:"600",color:"var(--saffron)"}}>{s.id}</td>
                <td style={{fontWeight:"600"}}>{s.name}</td><td>{s.class}</td>
                <td style={{color:"var(--text-muted)"}}>{s.phone}</td><td>{s.attendance}</td>
                <td style={{fontWeight:"600"}}>{s.score}%</td>
                <td><span className={`badge ${s.fee==="Paid"?"badge-green":"badge-red"}`}>{s.fee}</span></td>
                <td><button className="edit-btn">Edit</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AdminInquiries() {
  const [data, setData] = useState(inquiries);
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead><tr><th>Name</th><th>Class</th><th>Phone</th><th>Subject</th><th>Date</th><th>Status</th></tr></thead>
        <tbody>
          {data.map((i,idx) => (
            <tr key={i.name}>
              <td style={{fontWeight:"600"}}>{i.name}</td><td>{i.class}</td>
              <td><a href={`https://wa.me/91${i.phone}`} target="_blank" rel="noopener noreferrer" className="wa-link">💬 {i.phone}</a></td>
              <td>{i.subject}</td><td style={{color:"var(--text-muted)"}}>{i.date}</td>
              <td>
                <select className="status-select" value={i.status} onChange={e => setData(d => d.map((x,j) => j===idx?{...x,status:e.target.value}:x))}>
                  <option>New</option><option>Contacted</option><option>Enrolled</option>
                </select>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function AdminAnalytics() {
  const months = ["Oct","Nov","Dec","Jan","Feb","Mar"];
  const enroll = [35,42,28,55,48,62];
  const maxE = Math.max(...enroll);
  return (
    <div className="dashboard-grid">
      <div className="glass dash-card">
        <h4 className="dash-card-title">📈 Monthly Enrollments</h4>
        <div className="bar-chart">
          {months.map((m,i) => (
            <div key={m} className="bar-col">
              <div className="bar-wrap"><div className="bar-fill" style={{height:`${(enroll[i]/maxE)*100}%`}} /></div>
              <div className="bar-label">{m}</div>
              <div className="bar-val">{enroll[i]}</div>
            </div>
          ))}
        </div>
      </div>
      <div className="glass dash-card">
        <h4 className="dash-card-title">📊 Course Distribution</h4>
        {[["Class 9-10","40%","var(--saffron)"],["Class 11-12 Science","45%","var(--gold)"],["Arts & Commerce","15%","#34D399"]].map(([c,p,col]) => (
          <div key={c} style={{marginBottom:"14px"}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:"5px"}}>
              <span style={{fontSize:"13px"}}>{c}</span><span style={{fontSize:"13px",fontWeight:"600",color:col}}>{p}</span>
            </div>
            <div className="progress-bar"><div style={{height:"8px",borderRadius:"4px",background:col,width:p}} /></div>
          </div>
        ))}
      </div>
    </div>
  );
}

function AdminFees() {
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead><tr><th>Student</th><th>Class</th><th>Fee</th><th>Paid</th><th>Due</th><th>Status</th></tr></thead>
        <tbody>
          {students.map(s => (
            <tr key={s.id}>
              <td style={{fontWeight:"600"}}>{s.name}</td><td>{s.class}</td>
              <td>₹{s.class.includes("12")||s.class.includes("11")?"12,000":"6,000"}</td>
              <td style={{color:"var(--green)"}}>₹{s.fee==="Paid"?(s.class.includes("12")||s.class.includes("11")?"12,000":"6,000"):"0"}</td>
              <td style={{color:s.fee==="Pending"?"var(--red)":"var(--text-muted)"}}>{s.fee==="Pending"?"₹6,000":"₹0"}</td>
              <td><span className={`badge ${s.fee==="Paid"?"badge-green":"badge-red"}`}>{s.fee}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function AdminContent() {
  return (
    <div>
      <div style={{display:"flex",gap:"12px",flexWrap:"wrap",marginBottom:"24px"}}>
        {["+ Add Course","+ Upload Video","+ Upload Material","+ Add Topper"].map(l => (
          <button key={l} className="btn-primary sm">{l}</button>
        ))}
      </div>
      <div className="glass dash-card" style={{textAlign:"center",padding:"48px"}}>
        <div style={{fontSize:"48px",marginBottom:"12px"}}>📋</div>
        <p style={{fontSize:"15px",fontWeight:"600"}}>Content Management Panel</p>
        <p style={{fontSize:"13px",color:"var(--text-muted)",marginTop:"8px"}}>Connect to your backend API for full CRUD operations on courses, videos, materials, and toppers.</p>
      </div>
    </div>
  );
}

// ─── APP ────────────────────────────────────────────────────────────────────
export default function App() {
  const [view, setView] = useState("website");
  const [videoModal, setVideoModal] = useState(null);
  return (
    <>
      {/* Floating WhatsApp */}
      <div className="wa-float">
        <a href="https://wa.me/919507495828?text=Hello!+I+want+to+know+more+about+Gurukulam+Study+Point" target="_blank" rel="noopener noreferrer">
          <button className="wa-btn"><div className="wa-ping" />💬</button>
        </a>
      </div>
      {/* Admin shortcut */}
      <div className="admin-shortcut">
        <button className="btn-outline" style={{fontSize:"12px",padding:"8px 14px"}} onClick={() => setView("admin")}>⚙️ Admin</button>
      </div>
      {/* Portals */}
      {view==="student" && <StudentPortal onClose={() => setView("website")} />}
      {view==="admin" && <AdminDashboard onClose={() => setView("website")} />}
      {videoModal && <VideoModal video={videoModal} onClose={() => setVideoModal(null)} />}
      {/* Website */}
      <div style={{opacity:view==="website"?1:0,pointerEvents:view==="website"?"all":"none"}}>
        <Navbar onPortalOpen={() => setView("student")} />
        <HeroSection />
        <CoursesSection />
        <FacultySection />
        <VideoSection onVideoOpen={v => setVideoModal(v)} />
        <TopperSection />
        <StatsSection />
        <FacilitiesSection />
        <TestimonialsSection />
        <GallerySection />
        <ContactSection />
        <Footer />
      </div>
    </>
  );
}
