# 🎓 Gurukulam Study Point – Coaching Management Platform

**Best Coaching for 12th Science | Special Bihar Boards**
📍 Brahima More, Gopalganj, Bihar | 📱 +91 9507495828

---

## 🚀 Quick Start

### Prerequisites
- Node.js 16+ installed
- npm or yarn

### Installation & Run

```bash
# Install dependencies
npm install

# Start development server
npm start
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Build for Production

```bash
npm run build
```

---

## 📁 Project Structure

```
gurukulam/
├── public/
│   └── index.html          # HTML entry point (SEO optimized)
├── src/
│   ├── index.js            # React entry point
│   ├── App.jsx             # Main application (all components)
│   └── styles.css          # Complete styling
├── package.json
└── README.md
```

---

## ✨ Features

### 🌐 Public Website
- Animated hero section with WhatsApp CTA
- 3 Course cards (₹6K / ₹12K / ₹8K) with enrollment links
- Rituraj Sir faculty profile
- YouTube video lecture cards with modal player
- 5 Topper students showcase
- Animated stats counters
- 6 Facilities cards
- Student testimonials
- Campus gallery
- Admission inquiry form → WhatsApp integration
- Floating WhatsApp chat button
- SEO-optimized footer

### 👨‍🎓 Student Portal (Click "Student Login")
- Demo login (any credentials work)
- Dashboard with KPI cards
- My Courses with progress bars
- Video Lectures with embedded YouTube player
- Study Materials download
- **Live Online Test** – MCQs, 5-min timer, auto-score
- Results history table
- Attendance with bar chart
- Fee status & receipt
- Announcements feed

### ⚙️ Admin Dashboard (Click "Admin" button, bottom-left)
- Demo login (any password works)
- Overview with KPI + recent data
- Student management with search
- Inquiry management with status update + WhatsApp links
- Analytics – enrollment bar chart, course distribution
- Fee tracking table
- Content management panel

---

## 🔧 Customization

### Update Contact Info
In `src/App.jsx`, search for `9507495828` and replace with actual number.

### Update Courses & Prices
Edit the `courses` array at the top of `src/App.jsx`.

### Update Faculty Info
Edit the `FacultySection` component in `src/App.jsx`.

### Update Colors
Edit CSS variables in `src/styles.css`:
```css
:root {
  --saffron: #FF6B00;   /* Primary orange */
  --navy: #0A1628;      /* Background */
  --gold: #F5A623;      /* Accent gold */
}
```

---

## 🛠 Tech Stack

- **React 18** – UI Framework
- **CSS3** – Custom animations & responsive design
- **Google Fonts** – Playfair Display, DM Sans, Baloo 2
- **YouTube Embed** – Video lectures

---

## 📦 Backend Integration (Next Steps)

To make this production-ready, connect to a backend:

1. **Database**: MongoDB / PostgreSQL for students, fees, tests
2. **Authentication**: JWT tokens for student/admin login
3. **API**: Node.js/Express REST API
4. **File Storage**: AWS S3 / Cloudinary for study materials
5. **Payment**: Razorpay/PayU for fee collection
6. **SMS/WhatsApp**: Twilio / WA Business API for notifications

---

## 📞 Support

WhatsApp: +91 9507495828
Location: Brahima More, Gopalganj, Bihar

© 2026 Gurukulam Study Point. All Rights Reserved.
